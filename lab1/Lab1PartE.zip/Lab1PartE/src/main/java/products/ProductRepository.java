package products;

/**
 * @author kush
 */
public interface ProductRepository {
    void save(Product product);
}
