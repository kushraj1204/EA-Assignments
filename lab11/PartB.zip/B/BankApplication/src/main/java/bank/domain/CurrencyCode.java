package bank.domain;

/**
 * @author kush
 */
public enum CurrencyCode {
    EURO,USD
}
