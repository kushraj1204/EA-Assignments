package bank.dto.request;

/**
 * @author kush
 */
public enum CurrencyCode {
    EURO,USD
}
