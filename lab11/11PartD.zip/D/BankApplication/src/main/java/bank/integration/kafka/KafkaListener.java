package bank.integration.kafka;

public interface KafkaListener {

}
