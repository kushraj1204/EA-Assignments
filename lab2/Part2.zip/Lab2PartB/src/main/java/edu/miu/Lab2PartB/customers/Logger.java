package edu.miu.Lab2PartB.customers;

public interface Logger {

    void log (String logstring);

}
