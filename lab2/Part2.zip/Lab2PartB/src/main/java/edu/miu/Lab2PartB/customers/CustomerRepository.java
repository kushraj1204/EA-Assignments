package edu.miu.Lab2PartB.customers;

public interface CustomerRepository {

	void save(Customer customer) ;

}
