package edu.miu.Lab2PartA.customers;

public interface Logger {

    void log (String logstring);

}
