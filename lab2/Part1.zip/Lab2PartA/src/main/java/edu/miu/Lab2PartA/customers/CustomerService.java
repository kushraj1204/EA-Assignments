package edu.miu.Lab2PartA.customers;

public interface CustomerService {

	void addCustomer(String name, String email, String street,String city, String zip);

}
