package edu.miu.Lab2PartA.customers;

public interface CustomerRepository {

	void save(Customer customer) ;

}
