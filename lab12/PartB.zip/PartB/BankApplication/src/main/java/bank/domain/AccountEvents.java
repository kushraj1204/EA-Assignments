package bank.domain;

/**
 * @author kush
 */
public enum AccountEvents {
    ADD_ACCOUNT,
    DEPOSIT_MONEY,
    WITHDRAW_MONEY,
    TRANSFER_MONEY
}
