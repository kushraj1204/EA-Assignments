package client;

/**
 * @author kush
 */
public enum CurrencyCode {
    EURO,USD
}
